document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('loginForm').addEventListener('submit', async function(event) {
        event.preventDefault();
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;

        let valid = true;

        // Clear previous error messages
        const usernameErrorElem = document.getElementById('usernameError');
        const passwordErrorElem = document.getElementById('passwordError');
        const successMessageElem = document.getElementById('successMessage');
        
        usernameErrorElem.textContent = '';
        passwordErrorElem.textContent = '';
        successMessageElem.textContent = '';

        // Validate username
        if (!username) {
            usernameErrorElem.textContent = 'Username is required';
            valid = false;
        }

        // Validate password
        if (!password) {
            passwordErrorElem.textContent = 'Password is required';
            passwordErrorElem.classList.remove('uppercase');
            valid = false;
        } else if (password.length < 6) {
            passwordErrorElem.textContent = 'Password must be at least 6 characters long';
            passwordErrorElem.classList.add('uppercase');
            valid = false;
        }

        if (valid) {
            try {
                // Hash the password (for demonstration purposes; do this on the server in a real application)
                const hashedPassword = await sha256(password);
                console.log('Username:', username);
                console.log('Hashed Password:', hashedPassword);
                successMessageElem.textContent = 'Login successful';
            } catch (error) {
                console.error('Error hashing password:', error);
                successMessageElem.textContent = 'An error occurred. Please try again.';
            }
        }
    });

    // Simple SHA-256 hash function
    async function sha256(message) {
        const msgBuffer = new TextEncoder().encode(message);
        const hashBuffer = await crypto.subtle.digest('SHA-256', msgBuffer);
        const hashArray = Array.from(new Uint8Array(hashBuffer));
        const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
        return hashHex;
    }
});
